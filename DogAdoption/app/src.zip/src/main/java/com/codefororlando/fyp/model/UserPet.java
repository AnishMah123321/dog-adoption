package com.codefororlando.fyp.model;

public class UserPet {

    private String name;
    private String dogname;
    private String breed;
    private String description;



    public UserPet(String name, String dogname, String breed, String description) {
        this.name = name;
        this.dogname = dogname;
        this.breed = breed;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDogname() {
        return dogname;
    }

    public void setDogname(String dogname) {
        this.dogname = dogname;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;

    }
}
