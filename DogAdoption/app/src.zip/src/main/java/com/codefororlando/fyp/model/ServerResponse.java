package com.codefororlando.fyp.model;

public class ServerResponse {
    private Boolean success;
    private String message;
    private User user;
    private UserPet userPet;


    public ServerResponse(Boolean success, String message, User user, UserPet userPet) {
        this.success = success;
        this.message = message;
        this.user = user;
        this.userPet = userPet;


    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    public User getUser() {
        return user;
    }
    public UserPet getUserPet() {
        return userPet;
    }

    public void setUserPet(UserPet userPet) {
        this.userPet = userPet;
    }
}
