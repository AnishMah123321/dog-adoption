package com.codefororlando.fyp;

import android.app.Application;



public class AppController extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}