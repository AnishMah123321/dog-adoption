package com.codefororlando.fyp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.codefororlando.fyp.adapter.DashboardAdapter;
import com.codefororlando.fyp.maps.MapActivity;
import com.codefororlando.fyp.model.ListData;
import com.codefororlando.fyp.signup.LoginActivity;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class Dashboard extends AppCompatActivity {
    private DrawerLayout dl;
    private ActionBarDrawerToggle toggle;
    private NavigationView nv;
    Context context;
    RecyclerView recyclerView;
    private DashboardAdapter.OnItemClickListener listener;
    private ImageView addPet, maps;
    Toolbar toolbar;
    public static final String KEY_SHARED_PREFS = "SharedPrefs";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_layout);

//        NavigationView navigationView = findViewById(R.id.nav_view);
//        View header = navigationView.getHeaderView(0);

        SharedPreferences sharedPreferences = getSharedPreferences(KEY_SHARED_PREFS,MODE_PRIVATE);
        String email = sharedPreferences.getString("email","");

        NavigationView navigationView = findViewById(R.id.nv);
        View header = navigationView.getHeaderView(0);

        if(!email.isEmpty()) {
            TextView nameTxt = header.findViewById(R.id.banner_useremail);
            nameTxt.setText(email);
        }



        bindView();
        context = this;

        toggle = new ActionBarDrawerToggle(this, dl, R.string.Navigation_Drawer_Open, R.string.Navigation_Drawer_Close);
        dl.addDrawerListener(toggle);
        toggle.syncState();
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.icoo);

        nv.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                switch (id) {

                    case R.id.profile:
                        Toast.makeText(Dashboard.this, "Profile", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.notification:
                        Toast.makeText(Dashboard.this, "Notification", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.share:
                        Intent shareIntent = new Intent(Intent.ACTION_SEND);
                        shareIntent.setType("text/plain");
                        String shareBody = "Here is the share content body";
                        shareIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                        shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);

                        startActivity(Intent.createChooser(shareIntent, "Share via"));

                        Toast.makeText(Dashboard.this, "Share", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.logout:
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(intent);
                        finish();
                        Toast.makeText(Dashboard.this, "Logout", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        return true;
                }

                return true;
            }
        });
        maps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, MapActivity.class);
                startActivity(intent);
            }
        });

        addPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this, AddPetActivity.class);
                startActivity(intent);
            }
        });


        ListData[] myList = new ListData[]{
                new ListData("Dog List Detail", android.R.drawable.ic_menu_info_details),
                new ListData("Dog Shelter Detail", android.R.drawable.ic_menu_info_details),
                new ListData("Adopt a Dog?", android.R.drawable.ic_menu_help),

        };

        DashboardAdapter myListAdapter = new DashboardAdapter(myList, listener);
        recyclerView.hasFixedSize();
        //recyclerView.setLayoutManager(new GridLayoutManager(this,3));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(myListAdapter);
    }
    private void bindView() {
        dl = findViewById(R.id.drawer);
        addPet = findViewById(R.id.addSign);
        nv = findViewById(R.id.nv);
        recyclerView = findViewById(R.id.recyclerView);
        toolbar = findViewById(R.id.toolbar);
        maps = findViewById(R.id.maps);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            if (dl.isDrawerOpen(GravityCompat.START)) {
                dl.closeDrawer(GravityCompat.START);
            } else {
                dl.openDrawer(GravityCompat.START);
            }
        }
        return super.onOptionsItemSelected(item);
    }
}
