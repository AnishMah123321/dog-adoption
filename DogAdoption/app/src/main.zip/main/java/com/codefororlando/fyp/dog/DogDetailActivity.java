package com.codefororlando.fyp.dog;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.codefororlando.fyp.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DogDetailActivity extends AppCompatActivity {
    private static final String TAG = "DogDetailActivity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dog_list);
        Log.d(TAG,"onCreate: started.");
        getIncomingIntent();

    }

    private void getIncomingIntent() {
        Log.d(TAG,"GetIntent: checking for incoming intents");
        if(getIntent().hasExtra("DogName")&& getIntent().hasExtra("Images")) {
            Log.d(TAG,"getIncomingIntent: found intent extras");
            String dogName = getIntent().getStringExtra("DogName");
            String images1 = getIntent().getStringExtra("Images");

            setImage(dogName,images1);
    }
    }

    private void setImage(String dogName, String images1) {
        Log.d(TAG,"setImage: setting the image and name to widgets");
        TextView dName = findViewById(R.id.dog_name);
        dName.setText(dogName);

        ImageView imageView = findViewById(R.id.dogImage);
    }
    }
