package com.codefororlando.fyp.shelter;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.codefororlando.fyp.R;
import com.github.clans.fab.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DetailShelterActivity extends AppCompatActivity {
    private static final String TAG = "DetailShelterActivity";
    RecyclerView fabRecycler;
    ImageView imageView;
    FloatingActionButton floatingActionEmail;
    FloatingActionButton floatingActionContact;




    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shelter_detail_activity);

        Log.d(TAG, "onCreate: started.");
        getIncomingIntent();


        floatingActionEmail = findViewById(R.id.fabLabelEmail);
        floatingActionEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setData(Uri.parse("Mail to: "));
                emailIntent.setType("message/rfc822");
                try {
                    startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                    finish();
                    Log.i("Finished sending email...", "");
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(DetailShelterActivity.this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        floatingActionContact = findViewById(R.id.fabLabelContact);
        floatingActionContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showContactDialog();

            }
        });

    }

    private void showContactDialog() {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(DetailShelterActivity.this);
        final LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.recycler_fab, null, false);
        alertDialog.setView(view);
        //  alertDialog.setTitle("Contact");

        fabRecycler = view.findViewById(R.id.fab_recycler);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        fabRecycler.setLayoutManager(layoutManager);

        final List<ContactList> contactLists = new ArrayList<>();
        contactLists.add(new ContactList("Sneha's Care Nepal", "980-8645023"));
        contactLists.add(new ContactList("Kathmandu Animal Treatment Centre", "984-3810363"));
        contactLists.add(new ContactList("Shree's Animal Rescue Nepal", "980-8645023"));
        contactLists.add(new ContactList("Community Dog Welfare Kopan", "980-3976378"));
        contactLists.add(new ContactList("Street Dog Care", "984-1075383"));

        final FabRecyclerAdapter adapter = new FabRecyclerAdapter(contactLists, this);
        fabRecycler.setAdapter(adapter);
        adapter.setonAddClickListener(new FabRecyclerAdapter.OnAddClickListener() {
            @Override
            public void onAddClick(int position) {
                String number = contactLists.get(position).getNumber();
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel: " + number));
                startActivity(intent);
                Toast.makeText(DetailShelterActivity.this, "asd"+contactLists.get(position).getNumber(), Toast.LENGTH_SHORT).show();
            }
        });
        alertDialog.create();
        alertDialog.show();

    }


    private void getIncomingIntent(){
        Log.d(TAG,"GetIntent: checking for incoming intents");
        if(getIntent().hasExtra("image_url")&& getIntent().hasExtra("image_name") && getIntent().hasExtra("dogShelter")) {
            Log.d(TAG,"getIncomingIntent: found intent extras");
            String imageUrl = getIntent().getStringExtra("image_url");
            String imageName = getIntent().getStringExtra("image_name");
            String dogShelter = getIntent().getStringExtra("dogShelter");
            setImage(imageUrl,imageName,dogShelter);
        }

    }
    private void setImage(String imageUrl, String imageName, String dogShelter) {
        Log.d(TAG,"setImage: setting the image and name to widgets");

        TextView name = findViewById(R.id.shelterDescription);
        name.setText(imageName);

        TextView dogS = findViewById(R.id.shelterD);
        dogS.setText(dogShelter);

       imageView = findViewById(R.id.shelterImage);
        Glide.with(this)
                .asBitmap()
                .load(imageUrl)
                .into(imageView);



    }
}
