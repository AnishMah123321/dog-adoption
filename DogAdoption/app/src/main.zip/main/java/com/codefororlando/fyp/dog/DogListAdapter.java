package com.codefororlando.fyp.dog;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.codefororlando.fyp.R;
import com.codefororlando.fyp.model.UserPet;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DogListAdapter extends RecyclerView.Adapter<DogListAdapter.MyViewHolder> {
    private static final String TAG = "DogListAdapter";

    Context context;
    private List<UserPet> userPetList;

    public DogListAdapter(Context ct, List<UserPet> userPetList) {
        this.context = ct;
        this.userPetList = userPetList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dog_list, parent,false);
        return new DogListAdapter.MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        UserPet userPet = userPetList.get(position);

        //loading the image
        holder.dogName.setText(userPet.getDogname());
        holder.dogDetail.setText(userPet.getDescription());

    }

    @Override
    public int getItemCount() {
        return userPetList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView dogName, dogDetail;
        CircularImageView imageView;
        RelativeLayout relativeLayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            dogName = itemView.findViewById(R.id.dog_name);
            dogDetail = itemView.findViewById(R.id.dogDetail);
            imageView = itemView.findViewById(R.id.dogImage);
            relativeLayout = itemView.findViewById(R.id.relativeLayout);


        }
    }
}
