package com.codefororlando.fyp.dog;

import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.codefororlando.fyp.R;
import com.codefororlando.fyp.model.UserPet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DogListActivity extends AppCompatActivity {
    RecyclerView recyclerView;
  List<UserPet> userPetList;
  private static final String URL_User = "http://192.168.43.238/api/public/userPet";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dog_list_recycler);

        recyclerView = findViewById(R.id.dog_list_recycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        userPetList = new ArrayList<>();

        loadPet();


    }

    private void loadPet() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_User, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray array = new JSONArray(response);

                    for (int i = 0; i < array.length(); i++) {

                        JSONObject object = array.getJSONObject(i);

                        userPetList.add(new UserPet(object.getString("name"),
                                object.getString("dogname"),
                                object.getString("breed"),
                                object.getString("description")
                        ));

                    }
                    DogListAdapter adapter = new DogListAdapter(DogListActivity.this, userPetList);
                    recyclerView.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        Volley.newRequestQueue(this).add(stringRequest);


    }
}
